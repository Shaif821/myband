<!DOCTYPE html>

    <head>
        <meta charset="utf-8">
        <title><?php echo(TITLE);?></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <link rel="stylesheet" href="css/main.css">

    </head>
    <body>
