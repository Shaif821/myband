<?php

$result = $mysqli->query("SELECT * FROM newsarticles");
